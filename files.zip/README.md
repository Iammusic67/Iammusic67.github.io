# Chris Kariuki Mungai — Portfolio Site

A static portfolio site (bio, journey, projects, skills, certificates,
contact) built with plain HTML/CSS/JS — no build step, deploys straight
to GitHub Pages.

## Editing the content

Everything you're likely to change lives in **`assets/js/content.js`**:
bio, about text, timeline, skills, certificates, projects, contact links.
Open that file, edit the text between the quotes, save. You don't need to
touch `index.html`, `style.css`, or `main.js` unless you want to change
the design.

To add a certificate file, see `assets/certificates/README.md`.

## A note on the repo name

For a GitHub Pages **user site** (the kind that lives at
`https://<username>.github.io`), the repository itself must be named
**exactly** `<username>.github.io`. Your GitHub account is `Iammusic67`,
so the repo needs to be named `Iammusic67.github.io` for the site to be
reachable at the root domain — GitHub Pages ignores any other name for
that special behavior.

If you specifically want "ChrisMungai" to appear in the URL, you have two
options: (1) rename your GitHub account to `ChrisMungai` (Settings →
Account → Change username), then name the repo `ChrisMungai.github.io`,
or (2) keep your current username and later attach a custom domain (e.g.
`chrismungai.dev`) to the `Iammusic67.github.io` repo via Pages settings.
The steps below use `Iammusic67.github.io`, which will work immediately
with no extra setup.

## Deploying to GitHub Pages

Run these from inside this folder:

```bash
# 1. Initialize git (skip if already a repo)
git init
git branch -M main

# 2. Create the repo on GitHub first (via github.com → New repository),
#    named exactly:  Iammusic67.github.io
#    Leave it empty — no README, no .gitignore, no license.

# 3. Connect this folder to that repo
git remote add origin https://github.com/Iammusic67/Iammusic67.github.io.git

# 4. Commit and push
git add .
git commit -m "Initial portfolio site"
git push -u origin main
```

That's it — no separate Pages configuration needed for a `username.github.io`
repo; GitHub serves it automatically from `main`. Give it 1–2 minutes, then
visit:

```
https://iammusic67.github.io
```

### If you'd rather use a project repo instead

If you want to keep this as a normal-named project (e.g.
`chris-portfolio`) instead of the special user-site repo, it also works —
your URL will just be `https://iammusic67.github.io/chris-portfolio/`
instead of the root domain. In that case, after pushing:

1. Go to the repo on GitHub → **Settings → Pages**
2. Under "Build and deployment", set **Source: Deploy from a branch**
3. Branch: `main`, folder: `/ (root)` → **Save**

## Local preview

No build tools needed — just open `index.html` in a browser, or serve it
locally:

```bash
python3 -m http.server 8000
# then visit http://localhost:8000
```

## Folder structure

```
index.html
assets/
  css/style.css        design + layout
  js/content.js         ← edit your bio, projects, skills, certs here
  js/main.js             rendering logic (no need to touch)
  certificates/          drop certificate PDFs/images here
.nojekyll                tells GitHub Pages to skip Jekyll processing
```
